# Christmas
This is a Mod for [Minetest](https://www.minetest.net/) ( [Github Repo](https://github.com/Minetest/minetest)), that adds festive christmas items and nodes.


![Screenshot](https://github.com/Extex101/christmas/blob/master/screenshot.png)

# Provides
 - Candy canes (If you eat too many you could get a sugar rush!)
 - Gingerbread man* (Just plain food)
 - Eggnog* (Just plain food)
 - Mince pie (Just plain food)
 - Stocking (You need one to get cool rewards every 1 hour and 30 minutes)
 - Christmas lights* (A nice way to decorate for christmas)
 - Red Bauble* (To decorate your tree)
 - Star* (The topper of your tree)
 - Present (Give a gift to a firend)
 - Sugar* (To craft your sweets)
 - Tree (The center of all decorations)

* Only obtainable as a Stocking reward


View the Minetest forum post [here](https://forum.minetest.net/viewtopic.php?f=9&t=23782&)


Have fun and Merry Christmas!!
