## Chat Logger

Allows players to see the last 100 chat messages, also allows you to search for keywords

## License

* MIT License (MIT) for the code.

Get source code [GitHub](https://github.com/Acronymmk/chatlogger)
