[mod] 3d_armor_gloves
=======================

Adds gloves/gauntlets to 3d_armor


Given how little I had to do code wise and graphics wise I have left the code and
texture copyrights with Stu and Davidthecreator. 


