See https://forum.minetest.net/viewtopic.php?f=11&t=13956
