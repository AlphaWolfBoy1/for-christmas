minetest.register_on_dieplayer(function(player)
	minetest.chat_send_player(player:get_player_name(), "You died at "..tostring(math.floor(player:get_pos().x))..","..tostring(math.floor(player:get_pos().y))..","..tostring(math.floor(player:get_pos().z)))
end)

path = minetest.get_modpath("soundstuff") .. "/"
dofile(path .. "sound_event_items.lua")
dofile(path .. "jukebox.lua")
dofile(path .. "bigfoot.lua")
dofile(path .. "racecar.lua")


--[[ local function checkPlayerPos(player)
    local pos = player:get_pos()
    if not pos then
        return false
    end
    return true
end

local function playNightNoise(player)
    if not checkPlayerPos(player) then
        return
    end
    local pos = player:get_pos()
    local milli = minetest.get_timeofday() * 24000
    if pos.y >= -5 and (milli >= 19000 or milli <= 4000) then
        minetest.sound_play("owl", {gain = 1.0, pos = pos, to_player = player:get_player_name()})
    end
end

local function playWindNoise(player)
    if not checkPlayerPos(player) then
        return
    end
    local pos = player:get_pos()
    minetest.sound_play("wind", {gain = 1.0, pos = pos, to_player = player:get_player_name()})
end

local function playTweetNoise(player)
    if not checkPlayerPos(player) then
        return
    end
    local pos = player:get_pos()
    local millihour = minetest.get_timeofday() * 24000
    if pos.y >= -5 and millihour >= 5000 and millihour <= 18000 then
        minetest.sound_play("birds", {gain = 1.0, pos = pos, to_player = player:get_player_name()})
    end
end

local function scheduleNoises()
    for _, player in ipairs(minetest.get_connected_players()) do
        minetest.after(math.random(5, 40), function()
            playTweetNoise(player)
        end)
        minetest.after(math.random(5, 35), function()
            playNightNoise(player)
        end)
    end
    minetest.after(30, function()
        for _, player in ipairs(minetest.get_connected_players()) do
            playWindNoise(player)
        end
        scheduleNoises()
    end)
end

-- Call the scheduling function to start playing the noises
scheduleNoises()

]]--

minetest.register_node("soundstuff:bird", {
  drawtype = "torchlike",
  use_texture_alpha = "clip",
	tiles = {"1birb.png"},
   walkable = false,

	groups = { dig_immediate = 2},
})

minetest.register_node(":ugx:ugx", {
   use_texture_alpha = "clip",
   drawtype = "airlike",
	tiles = {"blank.png"},
   light_source = 14,
   walkable = false,
	groups = {choppy=1},
})

minetest.register_node(":specialblocks:appleblock", {
   use_texture_alpha = "clip",
   drawtype = "normal",
	tiles = {"appleblock.png"},
   walkable = false,
	groups = {snappy=3},
})


minetest.register_abm({
	nodenames = {"ugx:ugx"},
	interval = 25,
	chance = 1,
	action = function(...)
		minetest.sound_play({name="ugx"}, 
		{max_hear_distance = 3, loop = false})
	end
})

minetest.register_abm({
	nodenames = {"ugx:errh"},
	interval = 10,
	chance = 1,
	action = function(...)
		minetest.sound_play({name="erth"}, 
		{max_hear_distance = 5, loop = false})
	end
})

minetest.register_abm({
	nodenames = {"soundstuff:bird"},
	interval = 15,
	chance = 1,
	action = function(...)
		minetest.sound_play({name="birds"}, 
		{max_hear_distance = 2, loop = false})
	end
})


-- Define the  node
minetest.register_node("soundstuff:weirdglass", {
    description = "weird glass",
    tiles = {"default_water.png^default_glass.png"}, -- Replace with your texture
    groups = {cracky = 3},
    drawtype = "allfaces",
    use_texture_alpha = "blend",
})


minetest.register_node(":__bulitn:serverhoster", {
    description = "Block with the image of the server hoster ( Walker)",
    tiles = {"walker.png"},
    groups = {cracky = 3},
    drawtype = "allfaces",
    use_texture_alpha = "blend",
})

-- Craft recipe for the fire extinguisher

-- Register a function to handle player deaths
minetest.register_on_dieplayer(function(player)
    local player_name = player:get_player_name()

    local player_pos = player:get_pos()
    minetest.sound_play("death", {
        pos = player_pos,
        max_hear_distance = 100,
        gain = 1.0,
    })
end)



-- Function to play a noise to players within a certain range
local function play_noise_to_players(pos, sound_name, distance)
    local players = minetest.get_connected_players()

    for _, player in ipairs(players) do
        local player_pos = player:get_pos()
        local player_name = player:get_player_name()
        local dist = vector.distance(pos, player_pos)

        if dist <= distance then
            minetest.sound_play(sound_name, {
                pos = player_pos,
                max_hear_distance = distance,
                to_player = player_name,
                gain = 1.0,
            })
        end
    end
end

-- Register a function to handle player joins
minetest.register_on_joinplayer(function(player)
    local player_pos = player:get_pos()

    -- Play a join noise to players within 10 blocks
    play_noise_to_players(player_pos, "join_noise", 50)
end)

-- Register a function to handle player leaves
minetest.register_on_leaveplayer(function(player)
    local player_pos = player:get_pos()

    -- Play a leave noise to players within 10 blocks
    play_noise_to_players(player_pos, "leave_noise", 50)
end)



-- Function to play a specified sound to players within a certain range
local function play_sound(sound_name)
    local players = minetest.get_connected_players()

    for _, player in ipairs(players) do
        local player_pos = player:get_pos()
        local player_name = player:get_player_name()

        minetest.sound_play(spooky_noise, {
            pos = player_pos,
            max_hear_distance = 30000,
            to_player = player_name,
            gain = 1.0,
        })
    end
end



minetest.register_node("soundstuff:big", {
	description = ("very big block"),
	wield_scale = {x = 2, y = 2, z = 1},
  visual_scale = 50,
	tiles = {{
		name = "fianimated.png",
		animation = {
			type = "vertical_frames",
			aspect_w = 16,
			aspect_h = 16,
			length = 0.7
		},
	}},
	drawtype = "torchlike",
	paramtype = "light",
	sunlight_propagates = true,
	light_source = 14,
	walkable = false,
	groups = {vessel = 1, dig_immediate = 3, attached_node = 1},
})


minetest.register_node("soundstuff:negative_damage_block", {
	description = "Instant heal block",
	tiles = {"object_marker_red.png"},
	groups = {cracky = 3},
  use_texture_alpha = "clip",
   drawtype = "allfaces",
  walkable=false,
	sounds = default.node_sound_ice_defaults(),
	damage_per_second = -65535,
})

minetest.register_node(":default:slimeblock", {
	description = ("Slime Block"),
	drawtype = "nodebox",
	tiles = {"bluestone_stickyblocks_slime.png"},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.25, -0.25, 0.25, 0.25, 0.25},
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}
		}
	},
	use_texture_alpha = "blend",
	sunlight_propagates = true,
	is_ground_content = false,
	groups = {oddly_breakable_by_hand = 3, fall_damage_add_percent = -100, bouncy = 75, wieldview = 4},
	
})


minetest.register_node(":specialblocks:facinating", {
	drawtype = "nodebox",
	tiles = {"clearred.png"},
	paramtype = "light",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.25, -0.25, -0.25, 0.25, 0.25, 0.25},
			{-0.5, -0.5, -0.5, 0.5, 0.5, 0.5}
		}
	},
	use_texture_alpha = "blend",
	sunlight_propagates = true,
	is_ground_content = false,
	groups = {oddly_breakable_by_hand = 3, fall_damage_add_percent = -10},
	
})
