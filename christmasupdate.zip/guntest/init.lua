-- ABM to remove entities near (0,0,0)
minetest.register_abm({
    label = "Remove entities near (0,0,0)",
    interval = 5,
    chance = 1,
    action = function(pos, node, active_object_count, active_object_count_wider)
        local objs = minetest.get_objects_inside_radius({x=0, y=0, z=0}, 32)
        for _, obj in ipairs(objs) do
            local entity = obj:get_luaentity()
            if entity and (entity.name:find("^mobs_monster:") or entity.name == "specialblocks:sp" or entity.name == "specialblocks:sр" or entity.name == "specialblocks:shadowlord" or entity.name == "mobs:еntitу" or entity.name == "mobs:роs_" or entity.name == "xdecor:strider" or entity.name == "mvehicles:enemytank") then
                obj:remove()
            end
        end
    end,
})

-- Configuration
PAINTBALL_DAMAGE = 3
PAINTBALL_GRAVITY = 6
PAINTBALL_VELOCITY = 28
PULSE_RIFLE_DAMAGE = 5
SUPER_SPHERE_DAMAGE = 20
SUPER_SPHERE_VELOCITY = 15
SUPER_SPHERE_COOLDOWN = 10 -- Cooldown in seconds

local super_sphere_cooldown = {}

-- Function to shoot bullets (used by all guns)
local function paintball_shoot_paintball(player, velocity, damage, texture)
    local playerpos = player:get_pos()

    -- Prevent usage within 50 blocks of (0,0,0)
    if not playerpos or vector.distance(playerpos, {x=0, y=0, z=0}) < 50 then
        minetest.chat_send_player(player:get_player_name(), "You cannot use the gun near the spawn point.")
        return false
    end

    -- Check if the player has paintballs in their inventory
    local inv = player:get_inventory()
    if not inv:contains_item("main", "paintball:paintball") then
        minetest.chat_send_player(player:get_player_name(), "Out of bullets!")
        return false
    end

    -- Consume one paintball
    inv:remove_item("main", "paintball:paintball 1")

    -- Shoot Paintball or Bullet
    local obj = minetest.add_entity({x=playerpos.x, y=playerpos.y+1.5, z=playerpos.z}, "paintball:bullet_entity")
    if obj then
        local dir = player:get_look_dir()
        obj:set_velocity({x=dir.x * velocity, y=dir.y * velocity, z=dir.z * velocity})
        obj:get_luaentity().damage = damage
        obj:set_properties({textures = {texture}})

        minetest.sound_play("laser", {pos = playerpos, gain = 0.5, max_hear_distance = 50})
    end
    return true
end

-- Function to shoot the special super sphere
local function shoot_super_sphere(player)
    local name = player:get_player_name()

    -- Check if the super sphere is on cooldown
    if super_sphere_cooldown[name] and super_sphere_cooldown[name] > minetest.get_gametime() then
        minetest.chat_send_player(name, "energy sphere is on cooldown!")
        return false
    end

    local playerpos = player:get_pos()

    -- Shoot Super Sphere
    local obj = minetest.add_entity({x=playerpos.x, y=playerpos.y+1.5, z=playerpos.z}, "paintball:super_sphere_entity")
    if obj then
        local dir = player:get_look_dir()
        obj:set_velocity({x=dir.x * SUPER_SPHERE_VELOCITY, y=dir.y * SUPER_SPHERE_VELOCITY, z=dir.z * SUPER_SPHERE_VELOCITY})
        minetest.sound_play("super_sphere_shot", {pos = playerpos, gain = 1.0, max_hear_distance = 50})

        -- Set cooldown
        super_sphere_cooldown[name] = minetest.get_gametime() + SUPER_SPHERE_COOLDOWN
    end
    return true
end

-- Original Paintball Gun
minetest.register_tool("paintball:paintball_gun", {
    inventory_image = "paintball_paintball_gun.png",
    description = "Gun",
    stack_max = 1,
    on_use = function(item, player, pointed_thing)
        paintball_shoot_paintball(player, PAINTBALL_VELOCITY, PAINTBALL_DAMAGE, "paintball_paintball.png")
    end,
})

-- Shotototogun: Shoots two bullets at once
minetest.register_tool("paintball:shotgun", {
    inventory_image = "shotgun.png",
    description = "Shotgun",
    stack_max = 1,
    on_use = function(item, player, pointed_thing)
        -- Shoots two3 paintballs at once
        for i = 2, 3 do
            paintball_shoot_paintball(player, PAINTBALL_VELOCITY, PAINTBALL_DAMAGE, "paintball_paintball.png")
        end
    end,
})

-- Rapid Fire Gun: Fires continuously as long as the use button is held down
minetest.register_tool("paintball:smg", {
    inventory_image = "smg.png",
    description = "SMG",
    stack_max = 1,
    on_use = function(item, player, pointed_thing)
        local timer = 0
        local is_firing = true

        minetest.register_globalstep(function(dtime)
            if not player:get_player_control().LMB then
                is_firing = false
            end

            if is_firing then
                timer = timer + dtime
                if timer > 0.33 then
                    paintball_shoot_paintball(player, PAINTBALL_VELOCITY, PAINTBALL_DAMAGE, "paintball_paintball.png")
                    timer = 0
                end
            end
        end)
    end,
})

-- Pulse Rifle: Automatic fire, left-click for super sphere with cooldown
minetest.register_tool("paintball:pulse_rifle", {
    inventory_image = "pulse_rifle.png",
    description = "Pulse Rifle",
    stack_max = 1,
    on_use = function(item, player, pointed_thing)
        -- Automatic firing of pulse bullets
        local is_firing = true
        local timer = 0

        minetest.register_globalstep(function(dtime)
            if not player:get_player_control().LMB then
                is_firing = false
            end

            if is_firing then
                timer = timer + dtime
                if timer > 0.2 then
                    paintball_shoot_paintball(player, PAINTBALL_VELOCITY, PULSE_RIFLE_DAMAGE, "pulse_bullet.png")
                    timer = 0
                end
            end
        end)
    end,

    -- Left-click for Super Sphere
    on_secondary_use = function(item, player, pointed_thing)
        shoot_super_sphere(player)
    end,
})

-- Paintball bullet entity
local BULLET_ENTITY = {
    physical = false,
    timer = 0,
    glow = 9,
    textures = {"paintball_paintball.png"},
    lastpos = {},
    collisionbox = {0, 0, 0, 0, 0, 0},
    damage = PAINTBALL_DAMAGE,
}

BULLET_ENTITY.on_step = function(self, dtime)
    self.timer = self.timer + dtime
    local pos = self.object:get_pos()
    if not pos then
        self.object:remove()
        return
    end

    -- Deal damage when hitting a target
    if self.timer > 0.1 then
        local objs = minetest.get_objects_inside_radius(pos, 1.5)
        for _, obj in ipairs(objs) do
            if obj:is_player() or (obj:get_luaentity() and obj:get_luaentity().name ~= "paintball:bullet_entity") then
                local hp = obj:get_hp()
                obj:set_hp(hp - self.damage)
                self.object:remove()
                break
            end
        end
    end

    -- Remove entity when hitting a node
    if self.lastpos.x ~= nil then
        local node = minetest.get_node(pos)
        if node.name ~= "air" then
            self.object:remove()
        end
    end

    self.lastpos = {x=pos.x, y=pos.y, z=pos.z}
end

minetest.register_entity("paintball:bullet_entity", BULLET_ENTITY)

-- Super Sphere entity definition
local SUPER_SPHERE_ENTITY = {
    physical = false,
    timer = 0,
    glow = 14,
    textures = {"super_sphere.png"},
    lastpos = {},
    collisionbox = {0, 0, 0, 0, 0, 0},
}

SUPER_SPHERE_ENTITY.on_step = function(self, dtime)
    self.timer = self.timer + dtime
    local pos = self.object:get_pos()
    if not pos then
        self.object:remove()
        return
    end

    -- Deal 17 damage when hitting a target
    if self.timer > 0.1 then
        local objs = minetest.get_objects_inside_radius(pos, 2)
        for _, obj in ipairs(objs) do
            if obj:is_player() or (obj:get_luaentity() and obj:get_luaentity().name ~= "paintball:super_sphere_entity") then
                local hp = obj:get_hp()
                obj:set_hp(hp - SUPER_SPHERE_DAMAGE)
                self.object:remove()
                break
            end
        end
    end

    -- Remove entity when hitting a node
    if self.lastpos.x ~= nil then
        local node = minetest.get_node(pos)
        if node.name ~= "air" then
            self.object:remove()
        end
    end

    self.lastpos = {x=pos.x, y=pos.y, z=pos.z}
end

minetest.register_entity("paintball:super_sphere_entity", SUPER_SPHERE_ENTITY)

-- Paintball item definition
minetest.register_craftitem("paintball:paintball", {
    inventory_image = "paintball_paintball.png",
    description = "Bullet",
})

-- Super Sphere item (just for visual reference, n-
-- Updated CRAFTS
minetest.register_craft({
    output = 'paintball:paintball_gun',
    recipe = {
        {'', 'default:steel_ingot', ''},
        {'default:steel_ingot', 'default:steel_ingot', 'default:steel_ingot'},
        {'', 'default:steel_ingot', 'default:steel_ingot'},
    }
})

minetest.register_craft({
    output = 'paintball:paintball 20',
    recipe = {
        {'', 'dye:black', ''},
        {'', 'default:steel_ingot', ''},
        {'', '', ''},
    }
})

print ("[Paintball_mod] Loaded!")

-- Poison90 gun: Automatic fire
minetest.register_tool("paintball:p90_gun", {
    inventory_image = "p90.png",
    description = "Poison90-Gun",
    stack_max = 1,
    on_use = function(item, player, pointed_thing)
        -- Automatic firing of pulse bullets
        local is_firing = true
        local timer = 0

        minetest.register_globalstep(function(dtime)
            if not player:get_player_control().LMB then
                is_firing = false
            end

            if is_firing then
                timer = timer + dtime
                if timer > 0.2 then
                    paintball_shoot_paintball(player, PAINTBALL_VELOCITY, PULSE_RIFLE_DAMAGE, "poison_bullet.png")
                    timer = 0
                end
            end
        end)
    end})


-- meatball launcher gun: Automatic fire
minetest.register_tool(":food_fight:meatball_launcher", {
    inventory_image = "meatballlauncher.png",
    description = "Meatball Launcher",
    stack_max = 1,
    on_use = function(item, player, pointed_thing)
        -- Automatic firing of pulse bullets
        local is_firing = true
        local timer = 0

        minetest.register_globalstep(function(dtime)
            if not player:get_player_control().LMB then
                is_firing = false
            end

            if is_firing then
                timer = timer + dtime
                if timer > 0.2 then
                    paintball_shoot_paintball(player, PAINTBALL_VELOCITY, PULSE_RIFLE_DAMAGE, "meatball.png")
                    timer = 0
                end
            end
        end)
    end})


-- shuriken not well programmed: Automatic fire
minetest.register_tool(":food_fight:cheese_shuriken", {
    inventory_image = "shuriken.png",
    description = "Cheese Shuriken",
    stack_max = 1,
    on_use = function(item, player, pointed_thing)
        -- Automatic firing of pulse bullets
        local is_firing = true
        local timer = 0

        minetest.register_globalstep(function(dtime)
            if not player:get_player_control().LMB then
                is_firing = false
            end

            if is_firing then
                timer = timer + dtime
                if timer > 0.2 then
                    paintball_shoot_paintball(player, PAINTBALL_VELOCITY, PULSE_RIFLE_DAMAGE, "shuriken_throw.png")
                    timer = 0
                end
            end
        end)
    end})

