-- mod made by Shadow-Wolf for dcws

-- sword
minetest.register_tool("astral_stuffs:astral_sword", {
	description = ("Astral Sword"),
	inventory_image = "astralsword.png",
	groups = {weapon = 1, sword = 1},
	light_source = 5,
	tool_capabilities = {
		full_punch_interval = 0.8,
		max_drop_level = 1,
		groupcaps = {
			snappy = {
				times = {1.7, 0.7, 0.25},
				uses = 0,
				maxlevel = 3
			},
		},
		damage_groups = {fleshy = 30, burns = 3},
	},
})

-- pick
minetest.register_tool("astral_stuffs:astral_pickaxe", {
	description = ("Astral Pickaxe"),
	inventory_image = "astralpick.png",
	groups = {tool = 1, pickaxe = 1},
	light_source = 0,
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level = 3,
		groupcaps={
			cracky = {
				times = {0.8, 0.8, 0.40},
				uses = 0,
				maxlevel = 3
			},
		},
		damage_groups = {fleshy = 10, burns = 2},
	},
})

-- shovel
minetest.register_tool("astral_stuffs:astral_shovel", {
	description = "Astral Shovel",
	inventory_image = "astralshovel.png",
	tool_capabilities = {
		max_drop_level=3,
		groupcaps={
			crumbly={times={[1]=0, [2]=0, [3]=0}, uses=0, maxlevel=3},
		}
	},
})

-- axe
minetest.register_tool("astral_stuffs:astral_axe", {
	description = "Astral Axe",
	inventory_image = "astralaxe.png",
	tool_capabilities = {
		max_drop_level=3,
		groupcaps={
			fleshy = {times={[1]=0, [2]=0, [3]=0}, uses=0, maxlevel=3},
			choppy={times={[1]=0, [2]=0, [3]=0}, uses=0, maxlevel=3},
		}
	},
})

-- armor

-- boots

	armor:register_armor("astral_stuffs:boots_astral", {
		description = ("Astral Boots"),
		inventory_image = "astral_stuffs_inv_boots_astral.png",
		groups = {armor_feet=1, armor_heal=25, armor_use=0, physics_speed=1.5,
				physics_jump=0.5, armor_fire=4},
		armor_groups = {fleshy=15},
		damage_groups = {cracky=2, snappy=1, level=3},
	})

-- ring

		armor:register_armor("astral_stuffs:astral_ring", {
		description = ("Astral Rings"),
		inventory_image = "astral_stuffs_inv_ring_astral.png",
		groups = {armor_hands=1, armor_heal=22, armor_use=0, physics_speed=1,
				physics_jump=0.5, armor_fire=2},
		armor_groups = {fleshy=15},
		damage_groups = {cracky=2, snappy=1, level=3},
	})

-- shield

armor:register_armor("astral_stuffs:astral_shield", {
	description = "Astral Shield",
	inventory_image = "astral_stuffs_inv_shield_astral.png",
	armor_groups = {fleshy=110},
	groups = {armor_shield=40, armor_heal=70, armor_fire=5, armor_use=0},
})

