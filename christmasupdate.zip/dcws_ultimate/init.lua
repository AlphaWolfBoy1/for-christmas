-- random stuffs or things that my friends asked me :p

-- register nodes

minetest.register_tool("dark_caves_wildsurvival:hello_kitty_pickaxe", {
    description = "Hello Kitty Pickaxe",
    inventory_image = "hkpick.png",
    wield_scale = {x = 2, y = 2, z = 1},
    tool_capabilities = {
        full_punch_interval = 0.5,
        max_drop_level=3,
        groupcaps={
            cracky = {times={[1]=2.1, [2]=2.1, [3]=2.1}, uses=80, maxlevel=3},
       crumbly = {times={[1]= 1.4, [2]=1.2, [3]=1.0}, uses=80, maxlevel=3},
       choppy = {times={[1]= 2.4, [2]=1.2, [3]=2.0}, uses=80, maxlevel=3},
        },
        damage_groups = {fleshy=5},
    },
})


minetest.register_node("dark_caves_wildsurvival:sand_of_doom", {
description = minetest.colorize("#610800", "SAND OF DOOM\n"),
	tiles = {"sandofdoom.png"},
	groups = {crumbly = 3, falling_node = 1, sand = 1},
	sounds = default.node_sound_sand_defaults(),
})

minetest.register_node("dark_caves_wildsurvival:super_crystal_animated", {
description = minetest.colorize("#9b30f2", "super crystal animated\n"),
    light_source = 14,
    paramtype = "light",
    drawtype="normal",
    pointable = true,
    tiles = {
      {name = "animatedcrystal.png",
        animation={
          type = "vertical_frames",

          aspect_w = 16,
          aspect_h = 16,

          length = 3,
        },
        align_style = "world",
        scale=16
      }
    },
  })


minetest.register_node("dark_caves_wildsurvival:colorblock", {
	description = ("colored block"),
    light_source = 10,
    paramtype = "light",
    drawtype="normal",
    pointable = true,
	tiles = {"coloredblock.png"},
	groups = {cracky = 4, stone = 10},
	drop = "dark_caves_wildsurvival:colorblock",
	legacy_mineral = false,
	sounds = default.node_sound_stone_defaults(),
})

minetest.register_tool("dark_caves_wildsurvival:air_sword", {
	description = ("Air Sword"),
	inventory_image = "airsword.png",
	groups = {weapon = 1, sword = 1},
	light_source = 0,
	tool_capabilities = {
		full_punch_interval = 0.5,
		max_drop_level = 1,
		groupcaps = {
			snappy = {
				times = {1.7, 0.7, 0.25},
				uses = 0,
				maxlevel = 3
			},
		},
		damage_groups = {fleshy = 30},
	},
})

minetest.register_craftitem("dark_caves_wildsurvival:gears_heart", {
	description = ("Gears Heart"),
	inventory_image = "gearheart.png"
})

minetest.register_tool("dark_caves_wildsurvival:ultra_dangerous_gear_grinder", {
description = minetest.colorize("#610800", "Ultra Dangerous Gear Grinder\n"),
	inventory_image = "dangerousgrinder.png",
    wield_scale = {x = 2, y = 2, z = 1},
	tool_capabilities = {
		full_punch_interval = 0.2,
		max_drop_level=1,
		groupcaps={
			choppy={times={[1]=10.10, [2]=0.10, [3]=0.10}, uses=5000, maxlevel=3},
		},
		damage_groups = {fleshy=50},
	},
	sound = {breaks = "default_tool_breaks"},
	groups = {axe = 1}
})

-- craft

minetest.register_craft({
	output = "dark_caves_wildsurvival:ultra_dangerous_gear_grinder",
	recipe = {
		{"dark_caves_wildsurvival:gears_heart", "dark_caves_wildsurvival:gears_heart", "dark_caves_wildsurvival:gears_heart"},
		{"basic_materials:gear_steel", "atium:atium_axe", "basic_materials:gear_steel"},
		{"basic_materials:gear_steel", "basic_materials:motor", "basic_materials:gear_steel"},
	},
})

minetest.register_craftitem("dark_caves_wildsurvival:myswiftgirl", {
description = minetest.colorize("#de49f5", "Swifties Heart\n"),
    inventory_image = "herheart.png",
    max_stack = 1
})

