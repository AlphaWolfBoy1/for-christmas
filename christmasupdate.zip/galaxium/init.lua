minetest.register_craftitem("galaxium:unobtarium_ingot", {
	description = "Unobtarium Ingot",
	inventory_image = "unobtarium_ingot.png",
})

minetest.register_craftitem("galaxium:galaxium_ingot", {
	description = "Galaxium Ingot",
	inventory_image = "galaxium_ingot.png",
})

minetest.register_craftitem("galaxium:titanium_plate", {
	description = "Titanium Plate",
	inventory_image = "titanium_plate.png",
})

minetest.register_craftitem("galaxium:amethyst_emblem", {
	description = "Amethyst Emblem",
	inventory_image = "emblem.png",
})

minetest.register_craftitem("galaxium:stardust", {
	description = "Stardust",
	inventory_image = "stardust.png",
})

minetest.register_craftitem("galaxium:crystal_dust", {
	description = "Crystal Dust",
	inventory_image = "crystal_dust.png",
})

minetest.register_craft({
	output = "galaxium:amethyst_emblem",
	recipe = {
		{"","galaxium:titanium_plate",""},
		{"galaxium:titanium_plate","caverealms:glow_amethyst","galaxium:titanium_plate"},
		{"","galaxium:titanium_plate",""},
	}
})

minetest.register_craft({
	type = "shapeless",
	output = "galaxium:stardust 2",
	recipe = {"galaxium:crystal_dust", "ethereal:fire_dust", "galaxium:pixie_dust", "technic:mithril_dust"}
})

minetest.register_craft({
	output = "galaxium:shield_galaxium",
	recipe = {
		{"galaxium:galaxium_ingot", "galaxium:amethyst_emblem", "galaxium:galaxium_ingot"},
		{"galaxium:galaxium_ingot", "galaxium:stardust", "galaxium:galaxium_ingot"},
		{"", "galaxium:galaxium_ingot", ""},
	}
})

minetest.register_craft({
	output = "galaxium:boots_galaxium",
	recipe = {
		{"galaxium:galaxium_ingot", "", "galaxium:galaxium_ingot"},
		{"galaxium:galaxium_ingot", "galaxium:stardust", "galaxium:galaxium_ingot"},
	}
})

minetest.register_craft({
	output = "galaxium:boots_galaxium",
	recipe = {
		{"galaxium:galaxium_ingot", "galaxium:stardust", "galaxium:galaxium_ingot"},
		{"galaxium:galaxium_ingot", "", "galaxium:galaxium_ingot"},
	}
})

minetest.register_craft({
	output = "galaxium:chestplate_galaxium",
	recipe = {
		{"basic_materials:brass_ingot", "technic:lead_ingot", "basic_materials:brass_ingot"},
		{"galaxium:pixie_dust", "galaxium:galaxium_ingot", "galaxium:pixie_dust"},
	}
})

minetest.register_craft({
	output = "galaxium:stardust_orb",
	recipe = {
		{"galaxium:galaxium_ingot", "cr_plus:crystal_glass", "galaxium:galaxium_ingot"},
		{"cr_plus:crystal_glass", "galaxium:stardust", "cr_plus:crystal_glass"},
		{"galaxium:galaxium_ingot", "cr_plus:crystal_glass", "galaxium:galaxium_ingot"},
	}
})

armor:register_armor("galaxium:shield_galaxium", {
	description = "Galaxium Shield",
	inventory_image = "galaxium_inv_shield_galaxium.png",
	armor_groups = {fleshy=110},
	groups = {armor_shield=100, armor_heal=90, armor_fire=1, armor_use=10},
})

armor:register_armor("galaxium:boots_galaxium", {
	description = "Galaxium Boots",
	inventory_image = "galaxium_inv_boots_galaxium.png",
	groups = {armor_feet=1, physics_speed=2.25, physics_jump=0.2, physics_gravity=-0.8, armor_use=10},
})

armor:register_armor("galaxium:chestplate_galaxium", {
	description = "Galaxium Pauldron",
	inventory_image = "galaxium_inv_chestplate_galaxium.png",
	armor_groups = {fleshy=10, radiation=100, physics_jump=-0.1, physics_speed=-0.2},
	groups = {armor_torso=1, armor_fire=1, armor_use=10},
})

table.insert(armor.elements, "orb")

armor:register_armor("galaxium:stardust_orb", {
	description = "Stardust Orb",
	inventory_image = "stardust_orb.png",
	groups = {armor_orb=1, physics_gravity=-0.65, armor_use=10},
})

minetest.register_craft({
	output = "galaxium:unobtarium_ingot",
	recipe = {
		{"","atium:atium_ingot",""},
		{"","terumet:ingot_tcop",""},
		{"","galaxium:crystal_dust",""},
	}
})

minetest.register_craft({
	output = "galaxium:crystal_dust",
	recipe = {
		{"ethereal:crystal_block","ethereal:crystal_ingot","ethereal:crystal_block"},
		{"ethereal:crystal_spike","ethereal:crystal_spike","ethereal:crystal_spike"},
		{"ethereal:crystal_block","ethereal:crystal_block","ethereal:crystal_block"},
	}
})

minetest.register_craft({
	output = "galaxium:galaxium_ingot",
	recipe = {
		{"terumet:ingot_raw","ethereal:crystal_ingot","terumet:ingot_raw"},
		{"galaxium:crystal_dust","galaxium:crystal_dust","terumet:ingot_raw"},
		{"","ethereal:crystal_block",""},
	}
})

minetest.register_craft({
	output = "galaxium:titanium_plate",
	recipe = {
		{"","galaxium:unobtarium_ingot",""},
		{"galaxium:unobtarium_ingot","galaxium:unobtarium_ingot","galaxium:unobtarium_ingot"},
		{"","galaxium:unobtarium_ingot",""},
	}
})

minetest.register_craft({
	output = "galaxium:stardust_orb",
	recipe = {
		{"galaxium:stardust","mobs:lava_orb","galaxium:stardust"},
		{"mobs:lava_orb","","mobs:lava_orb"},
		{"galaxium:stardust","mobs:lava_orb","galaxium:stardust"},
	}
})

minetest.register_craft({
	output = "galaxium:stardust",
	recipe = {
		{"galaxium:crystal_dust","galaxium:crystal_dust","galaxium:crystal_dust"},
		{"galaxium:crystal_dust","galaxium:titanium_plate","galaxium:crystal_dust"},
		{"galaxium:crystal_dust","galaxium:crystal_dust","galaxium:crystal_dust"},
	}
})

minetest.register_craft({
	output = "galaxium:chestplate_galaxium",
	recipe = {
		{"galaxium:galaxium_ingot","","galaxium:galaxium_ingot"},
		{"galaxium:stardust_orb","galaxium:stardust_orb","galaxium:stardust_orb"},
		{"galaxium:amethyst_emblem","galaxium:crystal_dust","galaxium:amethyst_emblem"},
	}
})

minetest.register_alias("galaxium:chestplate_stardust", "galaxium:stardust_orb")

local materials = {
	"galaxium",
	"unobtarium",
}

for _, name in pairs(materials) do
	minetest.register_alias("galaxium:"..name.."_bar", "galaxium:"..name.."_ingot")
end
