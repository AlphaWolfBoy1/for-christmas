-- gear boss made by alphawolfboy

mobs:register_mob("mobs_monster:gear", {
	type = "monster",
	passive = false,
	damage = 18,
	attack_type = "shoot",
--	dogshoot_switch = 1,
--	dogshoot_count_max = 40, -- nah bro
--	dogshoot_count2_max = 1, -- bruh  
--	reach = 60,
	shoot_interval = 2,
	arrow = "mobs_monster:gear_in_fire",
	shoot_offset = 0.1,
	hp_min = 500,
	hp_max = 700,
	armor = 30,
	knock_back = true,
	collisionbox = {-0.7, -1, -0.7, 0.7, 1.6, 0.7},
	visual = "upright_sprite",
	textures = {
		"mobs_gear.png",
	},
	visual_size = {x=2, y=2},
	makes_footstep_sound = true,
	sounds = {
		random = "mobs_spider",
		shoot_attack = "tnt_ignite",
	},
	walk_velocity = 7,
	run_velocity = 10,
	jump = true,
	view_range = 100,
	drops = {
		{name = "basic_materials:gear_steel", chance = 2, min = 0, max = 2},
		{name = "dark_caves_wildsurvival:gears_heart", chance = 25, min = 0, max = 1},
	},
	water_damage = 0,
	lava_damage = 0,
	light_damage = 0,
	fear_height = 2,
})


mobs:spawn({
	name = "mobs_monster:gear",
	nodes = {"default:placeholder"},
	neighbors = {"default:mese", "default:stone_with_mese", "air", "default:mossycobble"},
	chance = 1,
	active_object_count = 1,
})



-- firegear (weapon) like an arrow
mobs:register_arrow("mobs_monster:gear_in_fire", {
	visual = "sprite",
	visual_size = {x = 1, y = 1},
	textures = {"gear_in_fire.png"},
	velocity = 20,
	tail = 1,
	tail_texture = "gdportal.png",
	tail_size = 12,
	glow = 14,
	expire = 0.5,


	-- direct hit, no fire... just plenty of pain
	hit_player = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 5},
		}, nil)
	end,

	hit_mob = function(self, player)
		player:punch(self.object, 1.0, {
			full_punch_interval = 1.0,
			damage_groups = {fleshy = 10},
		}, nil)
	end,

	-- node hit
	hit_node = function(self, pos, node)
		mobs:boom(self, pos, 3)
	end
})

